import pygame
import math
import os
from settings import PATH, PATH_2, GREEN, RED

pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))


class Enemy:
    def __init__(self):
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        self.path = PATH
        self.path_switch = 0
        self.path_pos = 0
        self.move_count = 0
        self.stride = 1
        self.x, self.y = self.path[self.path_pos]
        self.hp_width = 40
        self.hp_height = 4


    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    def draw_health_bar(self, win):
        # determine hp position
        hp_x = self.x - self.width // 2
        hp_y = self.y - self.height // 2 - 5
        # calculate length of remaining hp
        hp_remain = self.hp_width * (self.health / self.max_health)
        # draw hp
        pygame.draw.rect(win, RED, [hp_x, hp_y, self.hp_width, self.hp_height])
        pygame.draw.rect(win, GREEN, [hp_x, hp_y, hp_remain, self.hp_height])

    def move(self):
        # set up starting point and destination
        destination_x, destination_y = self.path[self.path_pos + 1]
        original_x, original_y = self.path[self.path_pos]
        # calculate move distance
        move_distance = math.sqrt((destination_x - original_x) ** 2 + (destination_y - original_y) ** 2)
        # determine max count
        max_count = int(move_distance / self.stride)

        # distance for x,y per move
        if self.move_count < max_count:
            unit_vector_x = (destination_x - original_x) / move_distance
            unit_vector_y = (destination_y - original_y) / move_distance
            delta_x = unit_vector_x * self.stride
            delta_y = unit_vector_y * self.stride

            # move
            self.x += delta_x
            self.y += delta_y
            self.move_count += 1

        # change new start and destination
        else:
            self.path_pos = self.path_pos + 1
            self.move_count = 0


class EnemyGroup:
    def __init__(self):
        self.gen_count = 0
        self.gen_period = 120   # (unit: frame)
        self.reserved_members = []
        self.expedition = []
        self.period_count = 120

    def campaign(self):
        # send an enemy per 120 frame
        if self.period_count == self.gen_period:
            # send enemy
            if self.gen_count:
                self.expedition.append(Enemy())
                self.reserved_members.pop()
                self.gen_count -= 1
                self.period_count = 0
            else:
                self.period_count = 0
        self.period_count += 1

    def generate(self, num):
        # generate "num" enemy in reserved_members
        while num:
            self.reserved_members.append(Enemy())
            self.gen_count += 1
            num -= 1

    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)

import pygame
import time

WIN_WIDTH = 1024
WIN_HEIGHT = 600
BTN_WIDTH = 80
BTN_HEIGHT = 80
HP_WIDTH = 45
HP_HEIGHT = 45
FPS = 30

# color (RGB)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

#導入字體模組
pygame.font.init()
font = pygame.font.Font(pygame.font.get_default_font(), 36)

# initialization
pygame.init()

# load image (background, enemy, buttons)
background_image = pygame.transform.scale(pygame.image.load("images/Map.png"), (WIN_WIDTH, WIN_HEIGHT))
enemy_image = pygame.transform.scale(pygame.image.load("images/enemy.png"), (70, 70))
hp_image = pygame.transform.scale(pygame.image.load("images/hp.png"), (HP_WIDTH, HP_HEIGHT))
hp_grey_image = pygame.transform.scale(pygame.image.load("images/hp_gray.png"), (HP_WIDTH, HP_HEIGHT))
muse_image = pygame.transform.scale(pygame.image.load("images/muse.png"), (BTN_WIDTH, BTN_HEIGHT))
sound_image = pygame.transform.scale(pygame.image.load("images/sound.png"), (BTN_WIDTH, BTN_HEIGHT))
continue_image = pygame.transform.scale(pygame.image.load("images/continue.png"), (BTN_WIDTH, BTN_HEIGHT))
pause_image = pygame.transform.scale(pygame.image.load("images/pause.png"), (BTN_WIDTH, BTN_HEIGHT))
# create window surface
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
# set the title
pygame.display.set_caption("My first game")
# clock
clock = pygame.time.Clock()
# time(記錄程式執行的時間差作為一秒)(取最接近)
t0 = time.time()
time.sleep(2)
t1 = time.time()
deltaT = int(t1 - t0)

class Game:
    def __init__(self):
        # window

        # hp
        self.hp = 7
        self.max_hp = 10
        pass

    def game_run(self):
        # 歸零時鐘
        millisec = 0
        sec = 0
        min = 0
        run = True
        # game loop
        while run:
            clock.tick(FPS)
            # 秒分進位
            millisec = millisec + deltaT
            if millisec == 60:
                millisec = 0
                sec = sec + 1

            if sec == 60:
                sec = 0
                min = min + 1
            # event loop
            for event in pygame.event.get():
                print(event)
                if event.type == pygame.QUIT:
                    run = False

            # draw background
            win.blit(background_image, (0, 0))

            # draw enemy and health bar
            win.blit(enemy_image, (19, 240))
            pygame.draw.rect(win, (255, 0, 0), [19, 230, 70, 5])
            # draw menu (and buttons)
            pygame.draw.rect(win, (0, 0, 0), [0, 0, 1024, 83])
            # 以下為血量（城堡）
            win.blit(hp_image, (405, 35))
            win.blit(hp_image, (455, 35))
            win.blit(hp_grey_image, (505, 35))
            win.blit(hp_grey_image, (555, 35))
            win.blit(hp_grey_image, (605, 35))
            win.blit(hp_image, (405, 0))
            win.blit(hp_image, (455, 0))
            win.blit(hp_image, (505, 0))
            win.blit(hp_image, (555, 0))
            win.blit(hp_image, (605, 0))
            # 以下為按鈕
            win.blit(muse_image, (735, 0))
            win.blit(sound_image, (805, 0))
            win.blit(continue_image, (875, 0))
            win.blit(pause_image, (945, 0))
            # draw time
            pygame.draw.rect(win, (0, 0, 0), [0, 550, 130, 50])
            text_surface = font.render(f"{min}:{str(sec).zfill(2)}", True, (255, 255, 255))
            win.blit(text_surface, (30, 558))
            pygame.display.update()

if __name__ == "__main__":
    covid_game = Game()
    covid_game.game_run()

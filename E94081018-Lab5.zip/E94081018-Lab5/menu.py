import pygame
import os

# load image, then change its scale
MENU_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "upgrade_menu.png")), (200, 200))
UPGRADE_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "upgrade.png")), (60, 40))
SELL_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "sell.png")), (40, 40))


class UpgradeMenu:
    def __init__(self, x, y):
        # create buttons list
        self.__buttons = [Button(UPGRADE_IMAGE, "upgrade", x, y - 71), Button(SELL_IMAGE, "sell", x + 8, y + 74)]
        self.image = MENU_IMAGE
        self.upgrade_image = UPGRADE_IMAGE
        self.sell_image = SELL_IMAGE
        # set rect of each image
        self.upgrade_image_rect = self.upgrade_image.get_rect()
        self.sell_image_rect = self.sell_image.get_rect()
        self.upgrade_image_rect.center = (x, y - 71)
        self.sell_image_rect = self.upgrade_image.get_rect()
        self.sell_image_rect.center = (x + 8, y + 74)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # draw menu
        win.blit(self.image, self.rect)
        # draw button
        win.blit(self.upgrade_image, self.upgrade_image_rect)
        win.blit(self.sell_image, self.sell_image_rect)

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        # Return the button list
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        self.image = image
        # set rect of the image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        # Return Whether the button is clicked
        return True if self.rect.collidepoint(x, y) else False

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        # Return the button name
        return self.name
